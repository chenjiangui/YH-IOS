//
//  SYPTemplateV2.h
//  SYPTemplateV2
//
//  Created by 钱宝峰 on 2017/9/23.
//  Copyright © 2017年 钱宝峰. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SYPTemplateV2.
FOUNDATION_EXPORT double SYPTemplateV2VersionNumber;

//! Project version string for SYPTemplateV2.
FOUNDATION_EXPORT const unsigned char SYPTemplateV2VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SYPTemplateV2/PublicHeader.h>

#import <SYPTemplateV2/testTemplateViewController.h>




