//
//  testTemplateViewController.h
//  TestJson
//
//  Created by 钱宝峰 on 2017/9/25.
//  Copyright © 2017年 com.intfocus. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface testTemplateViewController : UIViewController

-(instancetype)initWithData:(NSArray *)data;

-(void)refreshView;

@end
